#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  cin >> n;
  int ans = log2(n) + 1;
  cout << ans << endl;
  return 0;
}
