#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  cin >> n;
  int ans = (n == 2) ? 2 : 1;
  cout << ans << endl;
  return 0;
}
