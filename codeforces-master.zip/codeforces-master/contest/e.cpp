#include<bits/stdc++.h>
#define PB push_back
#define MP make_pair
#define SZ size
#define F first
#define S second
#define LL long long
#define II pair< int, int >

using namespace std;

int main(){
	
	return 0;
}
