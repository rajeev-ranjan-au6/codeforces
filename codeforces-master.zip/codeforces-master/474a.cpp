#include<bits/stdc++.h>

using namespace std;

int main(){
	string a="qwertyuiopasdfghjkl;zxcvbnm,./",b,c;
	cin >> b >> c;
	if(b=='R'){
		for(int i=0;i<c.length();i++)
			for(int j=0;j<a.length();j++){
				if(a[j]==c[i])
					cout << 
	
