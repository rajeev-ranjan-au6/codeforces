#include<bits/stdc++.h>

using namespace std;

int main(){
	int cnt;
	string a;
	cin >> a;
	int ans=(a.length()+1)*26-a.length();
	cout << ans << endl;
	return 0;
}
