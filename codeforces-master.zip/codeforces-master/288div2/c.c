#include<stdio.h>

    for(i=0;i<r;i++)
    {
        a[i]+=r-i;
        count++;
    }
    for(i=0;i<r;i++)
    {
        if(a[i]=w[j++])
            k=j;
        for(j=0;j    
int main()
{
    int m,t,r,i,w[300],a[300],count=0;
    scanf("%d%d%d",&m,&t,&r);
    for(i=0;i<m;i++)
        scanf("%d",&w[i]);
    return 0;
}


